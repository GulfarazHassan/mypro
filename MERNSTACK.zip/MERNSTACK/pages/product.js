import axios from 'axios'
import ProductSummery from '../components/Product/ProductSummary'
import ProductAttributes from '../components/Product/ProductAttributes'
import baseUrl from '../utils/baseUrl'

function Product({ product }) {
  return (
    <>
     <ProductSummery {...product} />
     <ProductAttributes {...product} />
    </>
  )
}

Product.getInitialProps = async ({ query: { _id } }) => {
  // fetch data from server
  let url = `${baseUrl}/api/product`;
  let payload = { params: { _id } }
    let response = await axios.get(url, payload);
  // return response data as an object
  return { product: response.data }
  // note: this object will be merged to existing props
}

export default Product;
