// import products from '../../static/products.json';
import Product from '../../models/Product';
import connectionDB from '../../utils/connectDb';

connectionDB();

export default async (req, res) => {
    const products = await Product.find()
    console.log("Entering in to function")
     res.status(200).json(products)
}