function Signup() {
  return <>signup</>;
}

export default Signup;
