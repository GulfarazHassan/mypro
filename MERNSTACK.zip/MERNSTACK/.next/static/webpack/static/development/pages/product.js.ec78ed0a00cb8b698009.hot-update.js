webpackHotUpdate("static/development/pages/product.js",{

/***/ "./components/Product/AddProductToCart.js":
/*!************************************************!*\
  !*** ./components/Product/AddProductToCart.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
var _jsxFileName = "/Users/apple/Desktop/MyWork/MERNSTACK/components/Product/AddProductToCart.js";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;


function AddProductToCart() {
  return __jsx(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Input"], {
    type: "number",
    min: "1",
    placeholder: "Quantity",
    action: {
      color: "orange",
      value: 1,
      content: "Add to Cart",
      icon: "plus cart"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 4
    },
    __self: this
  });
}

/* harmony default export */ __webpack_exports__["default"] = (AddProductToCart);

/***/ })

})
//# sourceMappingURL=product.js.ec78ed0a00cb8b698009.hot-update.js.map